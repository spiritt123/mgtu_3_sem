Rails.application.routes.draw do
  root to: 'xml#index'
end
