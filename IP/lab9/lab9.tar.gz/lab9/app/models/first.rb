class First < ApplicationRecord
end
